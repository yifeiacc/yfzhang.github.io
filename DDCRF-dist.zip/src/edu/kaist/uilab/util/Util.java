package edu.kaist.uilab.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

public class Util {
	
	public static int waitingTime = 0;
	public static final String DATA_FOLDER = "d:/Data/";
	
	public static BufferedReader getUTF8Reader(String file) throws UnsupportedEncodingException, FileNotFoundException{
		return new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8" ));
	}

	public static void copyFile(String sourceFile, String targetFile) throws Exception{
		File file1 = new File(sourceFile);
		File file2 = new File(targetFile);
		if(!file1.exists()){
			return;
		}
		if(file2.exists()){
			return;
		}
		
		BufferedReader in = new BufferedReader(new FileReader(new File(sourceFile)));
		PrintWriter out = new PrintWriter(new FileWriter(new File(targetFile)));
		
		while(true){
			String line = in.readLine();
			if(line == null) break;
			out.write(line + "\n");
		}
		in.close();
		out.close();
		System.out.println("Copy :" + targetFile);
	}

	public static void writeHashMapToFile(String file, HashMap<?,?> hashMap) throws Exception{
		PrintWriter out = new PrintWriter(new FileWriter(new File(file)));
		
		Set<?> keys = hashMap.keySet();
		
		for(Object key : keys){
			out.write(key.toString() + "," + hashMap.get(key).toString() + "\n");
		}
		
		out.close();
//		System.out.println("File write complete :" + file);
	}
	
	public static List<String> makeStringListFromFile(String file) throws Exception {
		List<String> result = new ArrayList<String>();

		try{
			BufferedReader in = new BufferedReader(new FileReader(new File(file)));
			
			while(true){
				String temp = in.readLine();
				if ( temp == null ) break;
				result.add(temp);
			}
			
			in.close();
		
		}catch(FileNotFoundException e){
			PrintWriter out = new PrintWriter(new FileWriter(new File(file)));
			out.close();
		}
		
		return result;
	}
	
	public static Set<String> makeSetFromFile(String file) throws Exception {
		Set<String> result = new HashSet<String>();

		BufferedReader in = getUTF8Reader(file);
		String line = null;
		
		while((line = in.readLine()) != null){
			result.add(line.trim());
		}
		in.close();
		
		return result;
	}
	
	public static void appendStringToFile(String outputFilePath, String content) throws Exception{
		PrintWriter out;
		try{
			out = new PrintWriter(new FileWriter(new File(outputFilePath), true));
		}catch(FileNotFoundException e){
			out = new PrintWriter(new FileWriter(new File(outputFilePath), false));
		}
		out.write(content+"\n");
		out.close();
	}
	
	/**
	 * contents of List<?> to file, elements of list could be converted using .toString method
	 * @param outputFilePath file path
	 * @param mode true = append, false = make a new file
	 * @param list
	 * @throws IOException IO Exception
	 */
	public static void makeListFileFromList(String outputFilePath, boolean mode, List<?> list) throws IOException {
		PrintWriter out = new PrintWriter(new FileWriter(new File(outputFilePath), mode));
		for(Object element : list){
			out.write(element.toString()+"\n");
		}
		out.close();
	}
	
	/**
	 * 
	 * @param outputFilePath
	 * @param content
	 * @param add true = append string to the target file, false = make a new file
	 * @throws Exception
	 */
	public static void writeStringToFile(String outputFilePath, String content, boolean add) throws Exception{
		PrintWriter out = new PrintWriter(new FileWriter(new File(outputFilePath), add));
		out.write(content);
		out.close();
	}

	public static String getTag(String content, String tag) {
		String startTag = "<"+tag+">";
		String endTag = "</"+tag+">";
		if(content.indexOf(startTag) == -1 || content.indexOf(endTag) == -1)
			return null;
		
		return new String(content.split(startTag)[1].split(endTag)[0]);
	}

	/**
	 * make a string from inputfile and return the string
	 * whole contents will be stored only one String instance
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static String readFileToString(String fileName) throws IOException{
		String content = "";
		BufferedReader in = new BufferedReader(new FileReader(new File(fileName)));
		
		while(true){
			String temp = in.readLine();
			if ( temp == null ) break;
			
			content += temp;
		}
		
		in.close();

		return content;
	}

	
	public static Vector<Integer> sortByValue(Vector<Double> vector, int count){
		Vector<Integer> sortedList = new Vector<Integer>();
		
		for(int i=0 ; i < count ; i++){
			
			double maxValue = Double.MIN_VALUE;
			int maxIndex = -1;
			
			for(int j=0 ; j < vector.size() ; j++){
				if(vector.get(j) > maxValue){
					boolean exist = false;
					for(int k=0 ; k<sortedList.size(); k++){
						if (sortedList.get(k) == j){
							exist = true;
							break;
						}
					}
					if(!exist){
						maxValue = vector.get(j);
						maxIndex = j;
					}
				}
			}
			
			sortedList.add(maxIndex);
		}
		return sortedList;
	}

	public static List<String> makeStringListFromFile(File file) throws IOException {
		List<String> result = new ArrayList<String>();

		BufferedReader in = new BufferedReader(new FileReader(file));
		
		while(true){
			String temp = in.readLine();
			if ( temp == null ) break;
			result.add(temp);
		}
		
		in.close();
		
		return result;
	}

	public static void writeListToFile(String outputFilePath,
			List<?> chiSquareIndex, Vector<?> rowIndex) throws IOException {
		PrintWriter out = new PrintWriter(new FileWriter(new File(outputFilePath)));
		
		for(int i=0; i< chiSquareIndex.size(); i++){
			out.write(rowIndex.get(i).toString().replaceAll(",", ".") + ","+ chiSquareIndex.get(i).toString() +"\n" );
		}
		out.close();
	}
	
	public static void writeListToFile(String outputFilePath,
			List<?> list) throws IOException {
		PrintWriter out = new PrintWriter(new FileWriter(new File(outputFilePath)));
		
		for(int i=0; i< list.size(); i++){
			out.write(list.get(i).toString() +"\n" );
		}
		
		out.close();
	}
}
