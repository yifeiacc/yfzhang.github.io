package edu.kaist.uilab.ddcrf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

public class DDCRFMap {

	private HashMap<Integer, Integer> map;
	
	public DDCRFMap(){
		map = new HashMap<Integer, Integer>();
	}
	
	public DDCRFMap(int capacity){
		map = new HashMap<Integer, Integer>(capacity);
	}
	
	public void put(int key, int value){
		map.put(key, value);
	}
	
	public int get(int key){
		if(map.containsKey(key)){
			return map.get(key);
		}
		return 0;
	}
	
	public void increase(int key){
		if(map.containsKey(key)){
			int value = map.get(key);
			map.put(key, value+1);
		}else{
			map.put(key, 1);
		}
	}
	
	public void decrease(int key){
		if(map.containsKey(key)){
			int value = map.get(key);
			if(value == 1){
				map.remove(new Integer(key));
			}else{
				map.put(key, value-1);
			}
		}else{
			System.out.println("ERROR1 " + key);
			System.exit(0);
		}
	}

	public int size() {
		return map.size();
	}

	public void increase(int key, int size) {
		if(map.containsKey(key)){
			int value = map.get(key);
			map.put(key, value+size);
		}else{
			map.put(key, size);
		}

	}

	public void decrease(int key, int size) {
		if(map.containsKey(key)){
			int value = map.get(key) - size;
			map.put(key, value);
			if(value == 0){
				map.remove(new Integer(key));
			}else if(value < 0){
				System.out.println("ERROR7");
			}
		}else{
			System.out.println("ERROR1 " + key);
			System.exit(0);
		}
	}
	
	public List<Entry<Integer,Integer>> getRankedList(){
		Set<Entry<Integer,Integer>> set = map.entrySet();
		List<Entry<Integer,Integer>> rankedList = new ArrayList<Entry<Integer,Integer>>();
		for(Entry<Integer,Integer> entry:set){
			rankedList.add(entry);
		}
		Comparator<Entry<Integer,Integer>> c = new EntryComparator();
		Collections.sort(rankedList, c);
		return rankedList;
	}
	
}

class EntryComparator implements Comparator<Entry<Integer,Integer>>{

	@Override
	public int compare(Entry<Integer,Integer> o1, Entry<Integer,Integer> o2) {
        return (o1.getValue().equals(o2.getValue()) ? 0 : (o1.getValue() > o2.getValue() ? -1 : 1));
	}

}
