package edu.kaist.uilab.ddcrf;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import edu.kaist.uilab.ddcrf.model.FirstLevelDistanceModel;
import edu.kaist.uilab.ddcrf.model.FirstLevelMeanModel;
import edu.kaist.uilab.ddcrf.model.FirstLevelModel;
import edu.kaist.uilab.ddcrf.model.FirstLevelSeqModel;
import edu.kaist.uilab.ddcrf.model.FirstLevelTimeSeqModel;
import edu.kaist.uilab.util.Util;

public class DDCRFTestMain {

	public static void main(String[] args) throws Exception {
		double hPrior = 0.5;
		double alpha0 = 1;
		double gamma = 1;
		int numSampling = 100;
		int distance = 25;
		int days = 1;
		int decayType = DDCRFCore.LOGISTIC_DECAY;
		int prevChechNum = 2000;
		FirstLevelModel model = new FirstLevelTimeSeqModel(prevChechNum);
		
		List<String> wordList = Util.makeStringListFromFile("./data/bow/Traning-BOW-Words.txt");
		List<Document> documents = makeDocumentList("./data/bow/Traning-BOW.txt");
		List<Document> heldOutDocs = makeDocumentList("./data/bow/Testing-BOW.txt");

		DDCRFCore core = new DDCRFCore(numSampling, wordList, documents);
		core.sethPrior(hPrior);
		core.setDecayType(decayType);
		core.setDistanceDecayParam(distance);
		core.setTimeDecayParam(days);
		
		String decayFn=null;
		if(core.getDecayType() == DDCRFCore.WINDOW_DECAY){decayFn = "window";}
		else if(core.getDecayType() == DDCRFCore.EXPONENTIAL_DECAY){decayFn = "exponential";}
		else if(core.getDecayType() == DDCRFCore.LOGISTIC_DECAY){decayFn = "logistic";}
		
		//sampling
		core.setSampleHyper(false);
		core.setAlpha0(alpha0);
		core.setGamma(gamma);
		core.setModel(model);
		core.gibbsSampling();
		
		//write result
//		core.writeWT("./output/ddcrf/" + decayFn + "/" + model.getModelName() +"-" + "WT-D" + distance + "-T"+days+".csv");
//		core.writeDocumentTableTopic("./output/ddcrf/"+ decayFn + "/" + model.getModelName() +"-"+ "DTT-D" + distance + "-T"+days+".csv");
//		core.writeTopWords("./output/ddcrf/" + decayFn + "/" + model.getModelName() +"-"+"Top-Words-D" + distance + "-T"+days+".csv", 20);
//		core.writeOtherThings("./output/ddcrf/" + decayFn + "/" + model.getModelName() +"-"+"Others-D" + distance + "-T"+days+".csv");
	}

	public static List<Document> makeDocumentList(String string) throws Exception {
		BufferedReader in = new BufferedReader(new InputStreamReader(
				new FileInputStream(string)));
		List<Document> documents = new Vector<Document>();
		String line = null;
		double denominator = 1000*60*60*24;
		
		while((line=in.readLine()) != null){
			StringTokenizer st = new StringTokenizer(line, ",");
			long time = Long.valueOf(st.nextToken());
			double x = Double.valueOf(st.nextToken());
			double y = Double.valueOf(st.nextToken());
			double day = time/denominator;
			Document doc = new Document();
			doc.setTime(day);
			doc.setX(x);
			doc.setY(y);
			
			while(st.hasMoreTokens()){
				String word = st.nextToken();
				int wordNo = Integer.valueOf(word.split(":")[0]);
				int freq = Integer.valueOf(word.split(":")[1]);
				
				for(int i=0; i<freq; i++){
					doc.addWord(new Word(wordNo));
				}
			}
			documents.add(doc);
		}

		in.close();

		return documents;
	}

}
