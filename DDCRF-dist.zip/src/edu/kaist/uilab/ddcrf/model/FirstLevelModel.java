package edu.kaist.uilab.ddcrf.model;

import java.util.HashMap;

import edu.kaist.uilab.ddcrf.DDCRFCore;
import edu.kaist.uilab.ddcrf.Document;

public interface FirstLevelModel {
	
	public double decayFuntion(Document doc1, Document doc2, int topicNo, DDCRFCore core);

	public double[] getProbTopic(double[] probTopic, DDCRFCore ddcrfCore, Document doc,
			int docNo);

	public void removeCoordinateMean(double x, double y, int oldTopic,
			DDCRFCore ddcrfCore);

	public void addCoordinateMean(double x, double y, int newTopic,
			DDCRFCore ddcrfCore);
	
	public HashMap<Integer, Double> getTopicMeanX();
	public HashMap<Integer, Double> getTopicMeanY();

	public String getModelName();
}
