package edu.kaist.uilab.ddcrf.model;

import java.util.HashMap;

import edu.kaist.uilab.ddcrf.DDCRFCore;
import edu.kaist.uilab.ddcrf.Document;

public class FirstLevelMeanModel implements FirstLevelModel {
	private HashMap<Integer, Double> topicMeanX;
	private HashMap<Integer, Double> topicMeanY;


	public FirstLevelMeanModel(int prevChechNum) {
		setTopicMeanX(new HashMap<Integer, Double>());
		setTopicMeanY(new HashMap<Integer, Double>());
	}

	@Override
	public double decayFuntion(Document doc1, Document doc2, int topicNo,
			DDCRFCore core) {
		double rval = 0;
		
		double meanX = getTopicMeanX().get(topicNo);
		double meanY = getTopicMeanY().get(topicNo);
		
		double x = doc1.getX();
		double y = doc1.getY();
		
		double distance = Math.sqrt(Math.pow(meanX-x, 2) + Math.pow(meanY-y, 2));
		
		if(core.getDecayType() == DDCRFCore.EXPONENTIAL_DECAY){
			rval = Math.exp(-distance/core.getDistanceDecayParam()) ;
		}else if(core.getDecayType() == DDCRFCore.LOGISTIC_DECAY){
			rval = Math.exp(-distance+core.getDistanceDecayParam())/(1+ Math.exp(-distance+core.getDistanceDecayParam()));
		}else if(core.getDecayType() == DDCRFCore.WINDOW_DECAY){
			if(distance > core.getDistanceDecayParam()){
				rval = 0;
			}else{
				rval = 1;
			}
		}
		return rval;
	}

	@Override
	public double[] getProbTopic(double[] probTopic, DDCRFCore core, Document doc,
			int docNo) {
		
		for(int ki:core.getAllocTopicList()){
			probTopic[ki] = this.decayFuntion(doc, null, ki, core) * core.topicTableSum.get(ki);
		}
		
		return probTopic;
	}
	
	public void addCoordinateMean(double x, double y, int newTopic, DDCRFCore core) {
		if(getTopicMeanX().containsKey(newTopic)){
			double meanX = getTopicMeanX().get(newTopic);
			double meanY = getTopicMeanY().get(newTopic);
			
			meanX *= core.topicTableSum.get(newTopic);
			meanY *= core.topicTableSum.get(newTopic);
			meanX += x;
			meanY += y;
			getTopicMeanX().put(newTopic, meanX/((double)core.topicTableSum.get(newTopic)+1));
			getTopicMeanY().put(newTopic, meanY/((double)core.topicTableSum.get(newTopic)+1));
		}else{
			getTopicMeanX().put(newTopic, x);
			getTopicMeanY().put(newTopic, y);
		}
	}

	public void removeCoordinateMean(double x, double y, int oldTopic, DDCRFCore core) {
		if(core.topicTableSum.get(oldTopic) == 1){
			getTopicMeanX().remove(oldTopic);
			getTopicMeanY().remove(oldTopic);
			return;
		}
		double meanX = getTopicMeanX().get(oldTopic);
		double meanY = getTopicMeanY().get(oldTopic);
		
		meanX *= core.topicTableSum.get(oldTopic);
		meanY *= core.topicTableSum.get(oldTopic);
		meanX -= x;
		meanY -= y;
		getTopicMeanX().put(oldTopic, meanX/((double)core.topicTableSum.get(oldTopic)-1));
		getTopicMeanY().put(oldTopic, meanY/((double)core.topicTableSum.get(oldTopic)-1));
	}


	public void setTopicMeanX(HashMap<Integer, Double> topicMeanX) {
		this.topicMeanX = topicMeanX;
	}

	public HashMap<Integer, Double> getTopicMeanX() {
		return topicMeanX;
	}

	public void setTopicMeanY(HashMap<Integer, Double> topicMeanY) {
		this.topicMeanY = topicMeanY;
	}

	public HashMap<Integer, Double> getTopicMeanY() {
		return topicMeanY;
	}

	@Override
	public String getModelName() {
		return "Mean";
	}

}
