package edu.kaist.uilab.ddcrf.model;

public class SecondLevelModel {

}
