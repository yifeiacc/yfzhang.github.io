package edu.kaist.uilab.ddcrf.model;

import java.util.HashMap;
import java.util.List;

import edu.kaist.uilab.ddcrf.DDCRFCore;
import edu.kaist.uilab.ddcrf.Document;

public class FirstLevelSeqModel implements FirstLevelModel{
	private int prevCheckNum = 1000;

	public FirstLevelSeqModel(int prevChechNum) {
		this.prevCheckNum = prevChechNum;
	}

	@Override
	public double decayFuntion(Document doc1, Document doc2, int topicNo,
			DDCRFCore core) {
		double rval = 0;
		
		double x1 = doc1.getX();
		double x2 = doc2.getX();
		
		double y1 = doc1.getY();
		double y2 = doc2.getY();
		
		double time1 = doc1.getTime();
		double time2 = doc2.getTime();
		double timeGap = Math.abs(time1-time2);
		
		double distance = Math.sqrt(Math.pow(x1-x2, 2) + Math.pow(y1-y2, 2));
		
		if(core.getDecayType() == core.EXPONENTIAL_DECAY){
			rval = 0.5 * Math.exp(-distance/core.getDistanceDecayParam()) + 0.5 * Math.exp(-(double)(timeGap)/(core.getTimeDecayParam()));
		}else if(core.getDecayType() == core.LOGISTIC_DECAY){
			rval = 0.5 * Math.exp(-distance+core.getDistanceDecayParam())/(1+ Math.exp(-distance+core.getDistanceDecayParam())) + 0.5 *  Math.exp(-timeGap+core.getTimeDecayParam())/(1+ Math.exp(-timeGap+core.getTimeDecayParam()));
		}else if(core.getDecayType() == core.WINDOW_DECAY){
			if(timeGap > core.getTimeDecayParam() || distance > core.getDistanceDecayParam()){
				rval = 0;
			}else{
				rval = 1;
			}
		}
		return rval;
	}

	@Override
	public double[] getProbTopic(double[] probTopic, DDCRFCore core,
			Document doc, int docNo) {
		int prevDocNo = 0;
		
		if(docNo > prevCheckNum){
			prevDocNo = docNo - prevCheckNum;
		}
		
		List<Document> documents = core.getDocuments();
		for(int pi=prevDocNo ; pi < docNo ; pi++){
			Document prevDoc = documents.get(pi);
			List<Integer> tableList = prevDoc.getAllocatedTableList();
			
			for(int ti:tableList){
				int ki = prevDoc.getTopicOfTable(ti);
				probTopic[ki] += decayFuntion(doc, prevDoc, 0, core);
			}
		}
		return probTopic;
	}

	public void setPrevChecNum(int prevChecNum) {
		this.prevCheckNum = prevChecNum;
	}

	public int getPrevChecNum() {
		return prevCheckNum;
	}

	@Override
	public void removeCoordinateMean(double x, double y, int oldTopic,
			DDCRFCore ddcrfCore) {
	}

	@Override
	public void addCoordinateMean(double x, double y, int newTopic,
			DDCRFCore ddcrfCore) {
	}

	@Override
	public HashMap<Integer, Double> getTopicMeanX() {
		return null;
	}

	@Override
	public HashMap<Integer, Double> getTopicMeanY() {
		return null;
	}

	@Override
	public String getModelName() {
		return "Seq";
	}

}
