package edu.kaist.uilab.ddcrf.model;

import java.util.HashMap;

import edu.kaist.uilab.ddcrf.DDCRFCore;
import edu.kaist.uilab.ddcrf.Document;

public class FirstLevelHDPModel implements FirstLevelModel{

	@Override
	public double decayFuntion(Document doc1, Document doc2, int topicNo,
			DDCRFCore core) {
		return 1;
	}

	@Override
	public double[] getProbTopic(double[] probTopic, DDCRFCore ddcrfCore,
			Document doc, int docNo) {
		for(int ki: ddcrfCore.getAllocTopicList()){
			probTopic[ki] = ddcrfCore.topicTableSum.get(ki);
		}
		return probTopic;
	}

	@Override
	public void removeCoordinateMean(double x, double y, int oldTopic,
			DDCRFCore ddcrfCore) {
	}

	@Override
	public void addCoordinateMean(double x, double y, int newTopic,
			DDCRFCore ddcrfCore) {
	}

	@Override
	public HashMap<Integer, Double> getTopicMeanX() {
		return null;
	}

	@Override
	public HashMap<Integer, Double> getTopicMeanY() {
		return null;
	}

	@Override
	public String getModelName() {
		return "hdp";
	}

}
