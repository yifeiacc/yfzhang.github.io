package edu.kaist.uilab.ddcrf.model;

import java.util.HashMap;
import java.util.List;

import edu.kaist.uilab.ddcrf.DDCRFCore;
import edu.kaist.uilab.ddcrf.Document;

public class FirstLevelTimeSeqModel implements FirstLevelModel{
	private int prevCheckNum = Integer.MAX_VALUE;
	private double timeDecayparam;

	public FirstLevelTimeSeqModel(){}
	
	public FirstLevelTimeSeqModel(int prevChechNum) {
		this.prevCheckNum = prevChechNum;
	}

	@Override
	public double decayFuntion(Document doc1, Document doc2, int topicNo,
			DDCRFCore core) {
		double rval = 0;
		
		double time1 = doc1.getTime();
		double time2 = doc2.getTime();
		double timeGap = Math.abs(time1-time2);
		timeDecayparam = core.getTimeDecayParam();
		
		//exponential decay function
		if(core.getDecayType() == core.EXPONENTIAL_DECAY){
			rval =  Math.exp(-(double)(timeGap)/(timeDecayparam));
		}else if(core.getDecayType() == core.LOGISTIC_DECAY){
			rval =  Math.exp(-timeGap+timeDecayparam)/(1.0 + Math.exp(-timeGap+timeDecayparam));
		}else if(core.getDecayType() == core.WINDOW_DECAY){
			if(timeGap > timeDecayparam){
				rval = 0.0;
			}else{
				rval = 1.0;
			}
		}
		
		return rval;
	}

	@Override
	public double[] getProbTopic(double[] probTopic, DDCRFCore core,
			Document doc, int docNo) {
		int prevDocNo = 0;
		
		if(docNo > prevCheckNum){
			prevDocNo = docNo - prevCheckNum;
		}
		
		List<Document> documents = core.getDocuments();
		for(int pi=prevDocNo ; pi <= docNo ; pi++){
			Document prevDoc = documents.get(pi);
			List<Integer> tableList = prevDoc.getAllocatedTableList();
			for(int ti:tableList){
				int ki = prevDoc.getTopicOfTable(ti);
				
				try{probTopic[ki] += decayFuntion(doc, prevDoc, 0, core);}catch(Exception e){}
			}
		}
		return probTopic;
	}

	public void setPrevCheckNum(int prevCheckNum) {
		this.prevCheckNum = prevCheckNum;
	}

	public int getPrevCheckNum() {
		return prevCheckNum;
	}

	@Override
	public void removeCoordinateMean(double x, double y, int oldTopic,
			DDCRFCore ddcrfCore) {
	}

	@Override
	public void addCoordinateMean(double x, double y, int newTopic,
			DDCRFCore ddcrfCore) {
	}

	@Override
	public HashMap<Integer, Double> getTopicMeanX() {
		return null;
	}

	@Override
	public HashMap<Integer, Double> getTopicMeanY() {
		return null;
	}

	@Override
	public String getModelName() {
		return "TimeSeq " + timeDecayparam + " " ;
	}

}
