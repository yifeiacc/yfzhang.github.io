package edu.kaist.uilab.ddcrf;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import edu.kaist.uilab.util.PorterStemmer;

public class Document{
	private int docNo;
	private int author;
	private Vector<Word> wordsList;
	
	private DDCRFMap tableSum;
	private DDCRFMap topicOfTable;
	private List<Integer> allocTableList;
	private HashMap<Integer, List<Integer>> tableWords;
	
	private double time;
	private double x;
	private double y;

	public Document(){
		this.wordsList = new Vector<Word>();
	}
	
	public Document(int docLength){
		this.wordsList = new Vector<Word>();
	}

	public Document(HashMap<String, Integer> validWords, String content,
			List<String> wordList, HashMap<String, Integer> wordMap, boolean stemming) {
		this.wordsList = new Vector<Word>();
		makeDocument(validWords, wordList, content, wordMap, stemming);
	}
	
	public String toString(){
		return time + " " + wordsList;
	}

	private void makeDocument(HashMap<String, Integer> validWords,
			List<String> wordDic, String content,
			HashMap<String, Integer> wordMap, boolean stemming) {

		PorterStemmer stemmer = new PorterStemmer(); 
		BreakIterator bi = BreakIterator.getWordInstance();
		
		bi.setText(content);
		
		int startBound=bi.first();
		for (int endBound = bi.next(); endBound != BreakIterator.DONE; startBound = endBound, endBound = bi.next()){
			String word = new String(content.substring(startBound, endBound).toLowerCase());
			
			if(stemming == true){
				word = stemmer.stemming(word);
			}

			if(word.length() < 2 || !validWords.containsKey(word) ) continue;
			
			if(wordMap.containsKey(word)){
				this.addWord(new Word(wordMap.get(word)));
			}else{
				wordMap.put(word, wordDic.size());
				wordDic.add(word);
				this.addWord(new Word(wordMap.get(word)));
			}
		}		
		
	}
	
	public Word getWord(int wi){
		if(wi > getLength()){
			return null;
		}
		return wordsList.get(wi);
	}
	
	public List<Integer> getAllocatedTableList(){
		return allocTableList;
	}
	
	public void addTable(int tableNo){
		allocTableList.add(tableNo);
		tableWords.put(tableNo, new ArrayList<Integer>());
	}

	public void removeTable(int oldTable) {
		allocTableList.remove(new Integer(oldTable));
		tableWords.remove(oldTable);
	}
	
	public void putWordsToTable(int tableNo, int wordNo){
		tableWords.get(tableNo).add(wordNo);
	}
	
	public void removeWordsToTable(int tableNo, int wordNo){
		tableWords.get(tableNo).remove(new Integer(wordNo));
	}
	
	public List<Integer> getTableWords(int tableNo){
		return tableWords.get(tableNo);
	}
	
	public void decreaseTableSum(int tableNo){
		tableSum.decrease(tableNo);
		if(tableSum.get(tableNo) == 0){
			allocTableList.remove(new Integer(tableNo));
		}
	}
	
	public void increaseTableSum(int tableNo){
		tableSum.increase(tableNo);
	}
	
	public int getTableSum(int tableNo){
		return tableSum.get(tableNo);
	}
	
	public int getTotalTableSize(){
		return tableSum.size();
	}
	
	
	public Document(String stringValue, List<String> wordList, boolean stemming) {
		
		this.wordsList = new Vector<Word>();
		makeDocument(wordList, stringValue, stemming);
	}

	public Document(String content, List<String> wordList,
			HashMap<String, Integer> wordMap, boolean stemming) {
		
		this.wordsList = new Vector<Word>();
		makeDocument(wordList, content, wordMap, stemming);
	}

	public Document(String content, List<String> wordList,
			HashMap<String, Integer> wordMap, boolean stemming,
			HashMap<String, Integer> removeWordMap) {
		
		this.wordsList = new Vector<Word>();
		makeDocument(wordList, content, wordMap, stemming, removeWordMap);
	}
	
	public void setNewTableMap(){
		tableSum = new DDCRFMap();
		topicOfTable = new DDCRFMap();
		allocTableList = new ArrayList<Integer>();
		tableWords = new HashMap<Integer, List<Integer>>();
	}
	
	public void removeAll() {
		tableSum = null;
		topicOfTable = null;
		allocTableList = null;
		tableWords = null;

	}


	public int getNewTableNo() {
		int rval = 0;
		for(int i=0; ; i++){
			if(!allocTableList.contains(i)){
				rval = i;
				break;
			}
		}
		return rval;
	}
	
	public int getMaxTableNo(){
		int max = -1;
		
		for(int i:allocTableList){
			if(i > max) max = i;
		}
		
		return max;
	}

	public int getTopicOfTable(int ti) {
		return topicOfTable.get(ti);
	}
	
	public void setTopicOfTable(int ti, int k){
		topicOfTable.put(ti, k);
	}

	public void setTime(double time) {
		this.time = time;
	}

	public double getTime() {
		return time;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getX() {
		return x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getY() {
		return y;
	}

	public int getDocNo() {
		return docNo;
	}

	public void setDocNo(int docNo) {
		this.docNo = docNo;
	}
	
	public void addWord(Word word){
		wordsList.add(word);
	}

	public void addWord(int wordNo) {
		this.addWord(new Word(wordNo));
	}
	
	public int getLength() {
		return wordsList.size();
	}

	public int getNumWords() {
		return wordsList.size();
	}
	
	public void setWordsList(Vector<Word> wordsList){
		this.wordsList = wordsList;
	}

	public void setAuthor(int author) {
		this.author = author;
	}

	public int getAuthor() {
		return author;
	}

	private void makeDocument(List<String> wordDic, String content, boolean stemming){
		PorterStemmer stemmer = new PorterStemmer(); 
		BreakIterator bi = BreakIterator.getWordInstance();
		
		bi.setText(content);
		
		int startBound=bi.first();
		for (int endBound = bi.next(); endBound != BreakIterator.DONE; startBound = endBound, endBound = bi.next()){
			String word = new String(content.substring(startBound, endBound).toLowerCase());
			
			if(stemming == true){
				word = stemmer.stemming(word);
			}
			
			if(word.length() < 2) continue;
			
			if(wordDic.contains(word)){
				this.addWord(new Word(wordDic.indexOf(word)));
			}else{
				wordDic.add(word);
				this.addWord(new Word(wordDic.indexOf(word)));
			}
		}
	}

	private void makeDocument(List<String> wordDic, String content,
			HashMap<String, Integer> wordMap, boolean stemming) {
		
		PorterStemmer stemmer = new PorterStemmer(); 
		BreakIterator bi = BreakIterator.getWordInstance();
		
		bi.setText(content);
		
		int startBound=bi.first();
		for (int endBound = bi.next(); endBound != BreakIterator.DONE; startBound = endBound, endBound = bi.next()){
			String word = new String(content.substring(startBound, endBound).toLowerCase());
			
			if(stemming == true){
				word = stemmer.stemming(word);
			}
			
			if(word.length() < 2) continue;
			
			if(wordDic.contains(word)){
				this.addWord(new Word(wordMap.get(word)));
			}else{
				wordMap.put(word, wordDic.size());
				wordDic.add(word);
				this.addWord(new Word(wordMap.get(word)));
			}
		}
	}


	private void makeDocument(List<String> wordDic, String content,
			HashMap<String, Integer> wordMap, boolean stemming,
			HashMap<String, Integer> removeWordMap) {
		
		PorterStemmer stemmer = new PorterStemmer(); 
		BreakIterator bi = BreakIterator.getWordInstance();
		
		bi.setText(content);
		
		int startBound=bi.first();
		for (int endBound = bi.next(); endBound != BreakIterator.DONE; startBound = endBound, endBound = bi.next()){
			String word = new String(content.substring(startBound, endBound).toLowerCase());
			
			if(stemming == true){
				word = stemmer.stemming(word);
			}

			if(word.length() < 2 || removeWordMap.containsKey(word)) continue;
			
			if(wordMap.containsKey(word)){
				this.addWord(new Word(wordMap.get(word)));
			}else{
				wordMap.put(word, wordDic.size());
				wordDic.add(word);
				this.addWord(new Word(wordMap.get(word)));
			}
		}
	}
	
	public void makeDocument(List<String> wordDic, List<String> content,
			HashMap<String, Integer> wordMap, Set<String> validWords) {
		
		for(String word:content){
			if(!validWords.contains(word)) continue;
			
			if(wordMap.containsKey(word)){
				this.addWord(new Word(wordMap.get(word)));
			}else{
				wordMap.put(word, wordDic.size());
				wordDic.add(word);
				this.addWord(new Word(wordMap.get(word)));
			}
		}
	}


}

