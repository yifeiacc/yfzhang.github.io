package edu.kaist.uilab.ddcrf;

public class Word {
	private int table;
	private final int wordNo;
	
	public Word(int wordNo){
		this.wordNo = wordNo;
	}
	
	public Word(int wordNo, int table){
		this.table = table;
		this.wordNo = wordNo;
	}
	
	public int getTable() {
		return table;
	}
	public void setTable(int table) {
		this.table = table;
	}
	public int getWordNo() {
		return wordNo;
	}
	
}