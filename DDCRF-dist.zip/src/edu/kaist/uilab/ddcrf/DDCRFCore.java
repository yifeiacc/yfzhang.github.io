package edu.kaist.uilab.ddcrf;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Map.Entry;

import cern.jet.random.Beta;
import cern.jet.random.Binomial;
import cern.jet.random.Gamma;
import cern.jet.random.engine.DRand;
import edu.kaist.uilab.ddcrf.model.FirstLevelModel;

public class DDCRFCore {
	public static int WINDOW_DECAY = 0;
	public static int LOGISTIC_DECAY = 1;
	public static int EXPONENTIAL_DECAY = 2;
	public static int HDP = 3;
	
	private int wordSize;
	private int totalDoc;
	private int numSampling = 100;
	private int currentSampling = 0;
	private List<Document> documents;
	private List<String> wordList;
	
	private int totalTable;
	private List<Integer> allocTopicList;
	private HashMap<Integer, DDCRFArray> C_WT;
	public DDCRFMap topicTableSum;
	private DDCRFMap topicSum;
	
	private double hPrior = 0.5;
	private double gamma = 1;
	private double alpha0 = 1;
	
	private double alphaA = 1;
	private double alphaB = 1;
	private double gammaA = 1;
	private double gammaB = 1;
	private boolean sampleHyper = true;
	private boolean sampleEta = false;
	private boolean heldoutTesting = false;

	private int decayType=WINDOW_DECAY;
	private double distanceDecayParam = 100;
	private double timeDecayParam = 5;
	private double heldoutLikelihood;
	private double complexity;
	private double avgTopic;
	
	private FirstLevelModel model;
	private double oldHPrior;
	private double oldAlpha0;
	private double oldGamma;
	private boolean log;
	private String logFile;

	public DDCRFCore(){
	}
	
	public DDCRFCore(int numSampling, List<String> wordList, List<Document> documents) {
		setAllocTopicList(new ArrayList<Integer>(20));
		C_WT = new HashMap<Integer, DDCRFArray>();
		topicTableSum = new DDCRFMap();
		topicSum = new DDCRFMap();
		
		wordSize = wordList.size();
		totalDoc = (int) (documents.size() * 0.9);
		this.setDocuments(documents);
		this.wordList = wordList;
		this.numSampling = numSampling;
	}

	public void gibbsSampling(){
		long startTime = System.currentTimeMillis();
		Random random = new Random();
		int testCount=0;
		PrintWriter logout=null;
		
		if(log==true){
			//open log file
			try {
				logout = new PrintWriter(new FileWriter(new File(logFile)));
			} catch (IOException exception) {
				exception.printStackTrace();
			}
		}
		
		for(int iter=0; iter<numSampling; iter++){
			setCurrentSampling(iter);
			
			long passed = System.currentTimeMillis() - startTime;
			//print current status and save it to the log file.
			System.out.println(model.getModelName() + decayType + " Time = " + passed/1000 + ", Iter = " + iter + ", #topics = " + getAllocTopicList().size() + ", #tables = " + totalTable+ ", gamma = " + getGamma() + ", alpha = " + getAlpha0() + ", eta = " + hPrior);
			if(log==true) logout.write(model.getModelName() + decayType + " Time = " + passed/1000 + ", Iter = " + iter + ", #topics = " + getAllocTopicList().size() + ", #tables = " + totalTable+ ", gamma = " + getGamma() + ", alpha = " + getAlpha0() + ", eta = " + hPrior + "\n");
			
			for(int di=0; di<totalDoc; di++){
				Document doc = getDocuments().get(di);
				samplingTableOfWords(doc, iter, di, random);
				samplingTopicsOfTables(doc, di, random);
			}
			
			//sampling hyper parameter alpha, gamma, eta
			if(isSampleHyper()){
				samplingFirstLevelParameter(random);
				samplingSecondLevelParameter(random);
			}
			if(isSampleEta()){
				samplingDirichletPrior(random);
			}
			
			//calculate held-out likelihood when sampling iteration close to the final iteration
			if(isHeldoutTesting()){
				if((numSampling-iter) <= 1000){
					double bestLL = -Double.MAX_VALUE;
	
					//save current hyperparameters
					savePriors();
					for(int newIter = 0; newIter < 10; newIter++){
						for(int di=totalDoc; di<documents.size(); di++){
							Document doc = documents.get(di);
							samplingTableOfWords(doc, newIter, di, random);
							samplingTopicsOfTables(doc, di, random);
						}
						
						double likelihood = documentsLogLikelihood(documents.subList(totalDoc, documents.size()));
						if(bestLL < likelihood){
							bestLL = likelihood;
						}
					}
					//load current hyperparameters, recover model status
					recoverTestStatistics(documents.subList(totalDoc, documents.size()));
					loadPriors();
					
					double comp = documentsComplexity(documents.subList(0, totalDoc));

					System.out.println("\tBest Held-out log-likelihood = " + bestLL + "\tBest Complexity = " + comp);
					if(log==true) logout.println("\tBest Held-out log-likelihood = " + bestLL + "\tBest Complexity = " + comp);
					
					heldoutLikelihood += bestLL;
					complexity += comp;
					avgTopic += allocTopicList.size();
					testCount++;
				}
			}
		}
		
		if(log==true)logout.close();
		
		heldoutLikelihood /= testCount;
		complexity /= testCount;
		avgTopic /= testCount;
	}

	private void recoverTestStatistics(List<Document> removeDocs) {
		for(Document doc:removeDocs){
			for(int wi=0; wi<doc.getLength(); wi++){
				Word word = doc.getWord(wi);
				int wordNo = word.getWordNo();
				int topic = doc.getTopicOfTable(word.getTable());
				
				C_WT.get(topic).decrease(wordNo);
				topicSum.decrease(topic);
				if(topicSum.get(topic) == 0){
					allocTopicList.remove(new Integer(topic));
					C_WT.remove(new Integer(topic));
				}
			}
			
			totalTable -= doc.getAllocatedTableList().size();
			
			for(int t: doc.getAllocatedTableList()){
				int topic = doc.getTopicOfTable(t);
				topicTableSum.decrease(topic);
			}
			
			doc.removeAll();
		}
	}

	
	private void savePriors() {
		oldHPrior = hPrior;
		oldGamma = gamma;
		oldAlpha0 = alpha0;
	}

	private void loadPriors() {
		hPrior = oldHPrior;
		gamma = oldGamma;
		alpha0 = oldAlpha0;
	}

	private void samplingTopicsOfTables(Document doc, int di, Random random) {
		List<Integer> tableList = doc.getAllocatedTableList();
		
		for(int tableNo: tableList){
			//sampling each table
			
			List<Integer> tableWordsList = doc.getTableWords(tableNo);
			int oldTopic = doc.getTopicOfTable(tableNo);
			
			int[] wordCount = new int[wordSize];
			
			for(int wi: tableWordsList){
				C_WT.get(oldTopic).decrease(wi);
				// counting words frequency in this table
				wordCount[wi]++;
			}
			topicTableSum.decrease(oldTopic);
			topicSum.decrease(oldTopic, tableWordsList.size());

			//removing
			if(topicTableSum.get(oldTopic) == 0){
				if(topicSum.get(oldTopic) != 0){
					System.exit(0);
				}
				C_WT.remove(oldTopic);
				allocTopicList.remove(new Integer(oldTopic));
			}
			
			double[] f = new double[getMaxTopicNo()+2];
			double[] q = new double[getMaxTopicNo()+2];
			double[] m = new double[getMaxTopicNo()+2];
			m = model.getProbTopic(m, this, doc, di);
			
			for(int k:allocTopicList){
				int[] wordCountCopy = Utility.copyArray(wordCount);
				f[k] = cern.jet.stat.Gamma.logGamma((double)topicSum.get(k) + (double)wordSize * hPrior) - cern.jet.stat.Gamma.logGamma((double)topicSum.get(k) + (double)wordSize * hPrior + tableWordsList.size());
				
				for(int wi:tableWordsList){
					if(wordCountCopy[wi] > 0){
						f[k] += cern.jet.stat.Gamma.logGamma( hPrior  + (double)C_WT.get(k).get(wi) + (double)wordCountCopy[wi] ) - cern.jet.stat.Gamma.logGamma( hPrior + (double)C_WT.get(k).get(wi) );
						// prevent double calculation
						wordCountCopy[wi] = 0;
					}
				}
				q[k] = Math.log(m[k]) + f[k];
			}
			f[f.length-1] =  cern.jet.stat.Gamma.logGamma( (double)wordSize*hPrior) - cern.jet.stat.Gamma.logGamma((double)tableWordsList.size() + (double)wordSize*hPrior);
			
			int[] wordCountCopy = Utility.copyArray(wordCount);
			for(int wi:tableWordsList){
				if(wordCountCopy[wi] > 0){
					f[f.length-1] += cern.jet.stat.Gamma.logGamma( hPrior  + (double)wordCountCopy[wi] ) - cern.jet.stat.Gamma.logGamma( hPrior );
					wordCountCopy[wi] = 0;
				}
			}
			q[q.length-1] = Math.log(gamma) + f[f.length-1];
			
			logNormalize(q);
			
			double probSum = 0;
			for(int k: allocTopicList){
				probSum += Math.exp(q[k]);
				q[k] = probSum;
			}
			probSum += Math.exp(q[q.length-1]);
			q[q.length-1] = probSum;
			
			int newTopic = 0;
			double randNo = random.nextDouble() * probSum;

			List<Integer> newList = new ArrayList<Integer>(allocTopicList);
			newList.add(q.length-1);
			
			for (int k: newList) {
				if (randNo < q[k]) {
					newTopic = k;
					break;
				}
			}
			
			if(newTopic == q.length-1){
				// allocate & add new topic 
				newTopic = getNewTopicNo();
				C_WT.put(newTopic, new DDCRFArray(wordSize));
				allocTopicList.add(newTopic);
			}
			
			for(int wi: tableWordsList){
				C_WT.get(newTopic).increase(wi);
			}
			topicTableSum.increase(newTopic);
			topicSum.increase(newTopic, tableWordsList.size());
			doc.setTopicOfTable(tableNo, newTopic);
		}
	}

	private void samplingTableOfWords(Document doc, int iter, int docNo, Random random) {
		
		if(iter == 0) doc.setNewTableMap();
		
		//globally used parameters for this document.
		double[] m = new double[getMaxTopicNo()+2];
		m = model.getProbTopic(m, this, doc, docNo);
		double mSum = Utility.arraySum(m);

		for(int wi = 0; wi < doc.getLength(); wi++){
			//Sampling new table for words
			Word word = doc.getWord(wi);
			int wordNo = word.getWordNo();
			
			if(iter != 0){
				// remove a word from current allocated table
				int oldTable = word.getTable();
				int oldTopic = doc.getTopicOfTable(oldTable);
				
				C_WT.get(oldTopic).decrease(wordNo);
				topicSum.decrease(oldTopic);
				doc.decreaseTableSum(oldTable);
				doc.removeWordsToTable(oldTable, wordNo);
				
				if(doc.getTableSum(oldTable) == 0){
					// no word in the table, remove 'old' table from a document
					model.removeCoordinateMean(doc.getX(), doc.getY(), oldTopic, this);
					doc.removeTable(oldTable);
					topicTableSum.decrease(oldTopic);
					totalTable--;
					
					if(topicTableSum.get(oldTopic) == 0){
						// no word in the topic, delete 'old' topic
						C_WT.remove(oldTopic);
						getAllocTopicList().remove(new Integer(oldTopic));
					}
					
					// changing m
					m = new double[getMaxTopicNo()+2];
					m = model.getProbTopic(m, this, doc, docNo);
					mSum = Utility.arraySum(m);
				}
			}
			// end

			double[] probTable = new double[doc.getMaxTableNo()+2];
			double[] f_kTable = new double[getMaxTopicNo()+1];

			double kSum = 0;
			double probSum = 0;
			
			// pre calculation
			for(int ki : getAllocTopicList()){
				// calculate the probability of word given mixture component(topic)
				f_kTable[ki] = f_k(wordNo, ki);
				kSum += (m[ki] / (mSum+getGamma()) ) * f_kTable[ki];
			}
			
			// table probability
			for(int ti : doc.getAllocatedTableList()){
				probTable[ti] = (double)doc.getTableSum(ti) * f_kTable[ doc.getTopicOfTable(ti) ];
				probSum += probTable[ti];
			}
			probTable[probTable.length-1] =  getAlpha0() * ( kSum + ((getGamma()/(mSum + getGamma())) * (1.0 / (double)wordSize )) );
			probSum += probTable[probTable.length-1];
			
			// sampling table no
			double randNo = random.nextDouble() * probSum;
			double tempSum = 0;
			int newTable = 0;
			
			for (;; newTable++) {
				tempSum += probTable[newTable];
				if (randNo <= tempSum) break;
			}
			
			int newTopic = 0;
			if( newTable == probTable.length-1 ){
				// topic of new table
				probSum = 0;
				
				for(int k : getAllocTopicList()){
					m[k] *= f_kTable[k];
					probSum += m[k];
				}

				m[m.length-1] = getGamma() * (1.0/ (double)wordSize );
				probSum += m[m.length-1];
									
				randNo = random.nextDouble() * probSum;
				tempSum = 0;
				newTopic = 0;

				for (int k = 0; ; k++) {
					tempSum += m[k];
					if (randNo <= tempSum) {
						newTopic = k;
						break;
					}
				}
				
				newTable = doc.getNewTableNo();
				
				if(newTopic == m.length-1){
					// allocate & add new topic
					newTopic = getNewTopicNo();
					C_WT.put(newTopic, new DDCRFArray(wordSize));
					getAllocTopicList().add(newTopic);
				}
				doc.addTable(newTable);
				doc.setTopicOfTable(newTable, newTopic);
				
				model.addCoordinateMean(doc.getX(),doc.getY(),newTopic,this);
				topicTableSum.increase(newTopic);
				totalTable++;
				
				// changing m
				m = new double[getMaxTopicNo()+2];
				m = model.getProbTopic(m, this, doc, docNo);
				mSum = Utility.arraySum(m);
			}else{
				// allocate words into existing table
				newTopic = doc.getTopicOfTable(newTable);
			}
			
			word.setTable(newTable);
			C_WT.get(newTopic).increase(wordNo);
			topicSum.increase(newTopic);
			doc.increaseTableSum(newTable);
			doc.putWordsToTable(newTable, wordNo);
			//per word
		}
	}
	
	private void samplingFirstLevelParameter(Random random){
		Gamma gammaGenerator = new Gamma(gammaA, gammaB, new DRand(new Date()));
		Beta rBeta = new Beta(1, 1, new DRand(new Date()));
		Binomial rBinomial = new Binomial(1, 0.5, new DRand(new Date()));

		if(model.getModelName().equals("hdp")){
			//original hdp-lda case
			double eta = rBeta.nextDouble(gamma+1.0, totalTable);
			double pi = gammaA + allocTopicList.size() -1;
			double rate = gammaB -  Math.log(eta);
			pi = pi / (pi + rate * totalTable);
			double cc = rBinomial.nextInt(1, pi);
			if(cc==0){
				gamma = gammaGenerator.nextDouble(gammaA + allocTopicList.size(), rate);
			}else{
				gamma =  gammaGenerator.nextDouble(gammaA + allocTopicList.size() - 1.0, rate);
			}
			return;
		}

		double[] fSum = new double[totalTable];
		int idx = 0;
		for(int di=0; di<totalDoc; di++){
			Document currentDoc = documents.get(di);
			double sum = 0;
			
			for(int prevD = 0; prevD < di; prevD++){
				Document compareDoc =documents.get(prevD);
				int tableCount = compareDoc.getTotalTableSize();
				sum += tableCount * model.decayFuntion(compareDoc, currentDoc, 0, this);
			}
			
			for(int i=0; i<currentDoc.getTotalTableSize(); i++){
				fSum[idx] = sum;
				idx++;
			}
		}
		
		int step = 1000;
		double first = 0;
		double[] logProb = new double[step];

		if((gamma-(step*0.05)) < 0.1){
			first = 0.1;
		}else{
			first = gamma - (step*0.05);
		}
		
		for(int i=0; i<step; i++){
			double sum=0;
			double currentGamma = first + (0.1*i);
			
			for(int ti=0; ti<totalTable; ti++){
				sum += Math.log(currentGamma + fSum[ti]);
			}
			logProb[i] = allocTopicList.size()*Math.log(currentGamma) - sum + Math.log(gammaGenerator.pdf(currentGamma));
		}
		Utility.logNormalize(logProb);
		
		double probTable[] = new double[step];
		double probSum = 0;
		
		for(int i=0; i<step; i++){
			probSum += Math.exp(logProb[i]);
			probTable[i] = probSum;
		}
		
		double randNo = random.nextDouble() * probSum;
		int selectIndex = 0;
		for (int ti = 0; ; ti++) {
			if(randNo < probTable[ti]){
				selectIndex = ti;
				break;
			}
		}
		gamma = first + (0.1*selectIndex);
	}
	
	private void samplingSecondLevelParameter(Random random) {
		Gamma gammaGenerator = new Gamma(gammaA, gammaB, new DRand(new Date()));
		Beta rBeta = new Beta(1, 1, new DRand(new Date()));
		Binomial rBinomial = new Binomial(1, 0.5, new DRand(new Date()));
		
		double sumLogW, sSum, rate;
		for(int si=0; si<20; si++){
			sumLogW = 0;
			sSum = 0;
			for(int i=0; i<totalDoc; i++){
				double length = (double)documents.get(i).getLength();
				sumLogW += Math.log(rBeta.nextDouble(alpha0 + 1.0, (double)length));
				sSum += rBinomial.nextInt(1, (double)length/((double)length+alpha0) );
			}
			rate = alphaB - sumLogW;
			alpha0 = gammaGenerator.nextDouble(alphaA + totalTable - sSum , rate);
		}
	}

	private void samplingDirichletPrior(Random random) {
		double proposedHPrior = hPrior + random.nextGaussian();
		while(proposedHPrior < 0){
			proposedHPrior = hPrior + random.nextGaussian();
		}

		double likelihood = topicLikelihood(hPrior);
		double proposedLikelihood = topicLikelihood(proposedHPrior);
		
		if(proposedLikelihood > likelihood) hPrior = proposedHPrior;
		else if(proposedLikelihood/likelihood > random.nextDouble()) hPrior = proposedHPrior;
	}
	
	private double logNormalize(double[] q) {
		int size = allocTopicList.size();
		double logMax = 500;
		
		double max = q[q.length-1];
		for(int i : allocTopicList){
			if(q[i] > max){
				max = q[i];
			}
		}
		
		double logShift = logMax - Math.log(size+1) - max;
		double sum = 0;
		for(int i : allocTopicList){
			sum += Math.exp(q[i] + logShift);
		}
		sum += Math.exp(q[q.length-1] + logShift);
		
		double logNorm = Math.log(sum) - logShift;
		for(int i : allocTopicList){
			q[i] -= logNorm;
		}
		q[q.length-1] -= logNorm;
		return logNorm;
	}

	private double topicLikelihood(double prior) {
		int numTopic = allocTopicList.size();
		double logLikelihood = 0;
		for(int k:allocTopicList){
			logLikelihood += numTopic*cern.jet.stat.Gamma.gamma(prior);
			logLikelihood -= cern.jet.stat.Gamma.gamma(numTopic*prior);
			for(int wi=0; wi<wordSize; wi++){
				logLikelihood += (prior-1)*Math.log(f_k(wi,k));
			}
		}
		return Math.exp(logLikelihood);
	}

	private int getNewTopicNo() {
		int rval = 0;
		
		for(int i=0; ; i++){
			if(!getAllocTopicList().contains(i)){
				rval = i;
				break;
			}
		}
		
		return rval;
	}
	
	private int getMaxTopicNo(){
		int max = -1;
		for(int i : getAllocTopicList()){
			if(i>max){
				max = i;
			}
		}
		return max;
	}
	
	private double f_k(int wordNo, int k) {
		return ((double)C_WT.get(k).get(wordNo)+(double)gethPrior())/((double)topicSum.get(k) + gethPrior()*(double)wordSize);
	}
	
	public double documentsLogLikelihood(List<Document> docs){
		double likelihood = 0;
		
		for(Document doc:docs){
			for(int wi=0; wi<doc.getLength(); wi++){
				Word word = doc.getWord(wi);
				int wordNo = word.getWordNo();
				int topicNo = doc.getTopicOfTable(word.getTable());
				
				likelihood += Math.log(f_k(wordNo, topicNo));
			}
		}
		return likelihood;
	}
	
	public double documentsComplexity(List<Document> docs){
		double complexity = allocTopicList.size();
		
		for(Document doc:docs){
			List<Integer> kindsOfTopics = new ArrayList<Integer>();
			for(int t: doc.getAllocatedTableList()){
				int topic = doc.getTopicOfTable(t);
				if(!kindsOfTopics.contains(topic)){
					kindsOfTopics.add(topic);
				}
			}
			complexity += kindsOfTopics.size();
		}
		
		return complexity;
	}

	public void writeWT(String filename){
		PrintWriter out;
		try {
			out = new PrintWriter(new FileWriter(new File(filename)));
			
			for(int i=0; i<wordSize; i++){
//				out.write(wordList.get(i));
				for(int t : getAllocTopicList()){
					out.write((int)C_WT.get(t).get(i)+",");
				}
				out.write("\n");
			}
						
			out.close();
		} catch (IOException exception) {
			exception.printStackTrace();
		}

	}
	
	public void writeTopWords(String filename, int topwords){
		PrintWriter out;
		try {
			out = new PrintWriter(new FileWriter(new File(filename)));

			List<Entry<Integer,Integer>> topicList = topicSum.getRankedList();
			
			for(Entry<Integer,Integer> k:topicList){
				if(k.getValue() < topwords) continue;
				out.write(k.getKey() + ",");
			}
			out.write("\n");
			
			for(Entry<Integer,Integer> k:topicList){
				if(k.getValue() < topwords) continue;
				out.write(k.getValue() + ",");
			}
			out.write("\n");
			
			if(model.getModelName().equals("Mean")){
				for(Entry<Integer,Integer> k:topicList){
					if(k.getValue() < topwords) continue;
					out.write(model.getTopicMeanX().get(k.getKey()) + ",");
				}
				out.write("\n");
				
				for(Entry<Integer,Integer> k:topicList){
					if(k.getValue() < topwords) continue;
					out.write(model.getTopicMeanY().get(k.getKey()) + ",");
				}
				out.write("\n");
			}
			
			for(int i=0; i<topwords; i++){
				for(Entry<Integer,Integer> k:topicList){
					List<Entry<Integer,Integer>> list = C_WT.get(k.getKey()).getRankedList();
					if(list.size() < topwords) continue;
					out.write(wordList.get(list.get(i).getKey()) + ",");
				}
				out.write("\n");
			}
			
			out.close();
		} catch (IOException exception) {
			exception.printStackTrace();
		}
	}
	
	public void writeDocumentTableTopic(String filename){
		PrintWriter out;
		try {
			out = new PrintWriter(new FileWriter(new File(filename)));
			for(int di=0; di<totalDoc; di++){
				Document doc = documents.get(di);
				for(int wi = 0; wi < doc.getLength(); wi++){
					Word word = doc.getWord(wi);
					out.write(word.getWordNo()+":"+word.getTable()+":"+doc.getTopicOfTable(word.getTable())+" ");
				}
				out.write("\n");
			}
			out.close();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public void writeOtherThings(String filename) {
		PrintWriter out;
		try {
			out = new PrintWriter(new FileWriter(new File(filename)));
			out.write("Gamma," + getGamma() + "\n");
			out.write("Alpha," + getAlpha0() + "\n");
			out.write("Iteration," + numSampling + "\n");
			out.write("AverageTopic," + avgTopic + "\n");
			out.write("heldoutLikelihood," + heldoutLikelihood + "\n");
			out.write("complexity," + complexity + "\n");
			out.close();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	
	private boolean isSampleEta() {
		return sampleEta;
	}
	
	public void setSampleEta(boolean sample){
		this.sampleEta = sample;
	}

	public void setModel(FirstLevelModel model) {
		this.model = model;
	}

	public FirstLevelModel getModel() {
		return model;
	}

	public void setTimeDecayParam(double timeDecayParam) {
		this.timeDecayParam = timeDecayParam;
	}

	public double getTimeDecayParam() {
		return timeDecayParam;
	}

	public void setAllocTopicList(List<Integer> allocTopicList) {
		this.allocTopicList = allocTopicList;
	}

	public List<Integer> getAllocTopicList() {
		return allocTopicList;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void sethPrior(double hPrior) {
		this.hPrior = hPrior;
	}

	public double gethPrior() {
		return hPrior;
	}

	public void setDistanceDecayParam(double distanceDecayParam) {
		this.distanceDecayParam = distanceDecayParam;
	}

	public double getDistanceDecayParam() {
		return distanceDecayParam;
	}

	public void setDecayType(int decayType) {
		this.decayType = decayType;
	}

	public int getDecayType() {
		if(model.getModelName().equals("hdp")) return HDP;
		return decayType;
	}

	public void setSampleHyper(boolean sampleHyper) {
		this.sampleHyper = sampleHyper;
	}

	public boolean isSampleHyper() {
		return sampleHyper;
	}

	public void setGamma(double gamma) {
		this.gamma = gamma;
	}

	public double getGamma() {
		return gamma;
	}

	public void setAlpha0(double alpha0) {
		this.alpha0 = alpha0;
	}

	public double getAlpha0() {
		return alpha0;
	}

	public void setCurrentSampling(int currentSampling) {
		this.currentSampling = currentSampling;
	}

	public int getCurrentSampling() {
		return currentSampling;
	}
	
	public void setHeldoutTesting(boolean heldoutTesting) {
		this.heldoutTesting = heldoutTesting;
	}

	public boolean isHeldoutTesting() {
		return heldoutTesting;
	}

	public void saveLog(String string) {
		log = true;
		logFile = string;
	}
	
}
