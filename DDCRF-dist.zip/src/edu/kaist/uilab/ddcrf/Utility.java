package edu.kaist.uilab.ddcrf;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.Vector;

import edu.kaist.uilab.util.PorterStemmer;

public class Utility {

	private static PorterStemmer stemmer = new PorterStemmer();
	
	public static double logNormalize(double[] q) {
		int size = q.length;
		double logMax = 500;
		
		double max = q[q.length-1];
		for(int i=0; i<q.length; i++){
			if(q[i] > max){
				max = q[i];
			}
		}
		
		double logShift = logMax - Math.log(size) - max;
		double sum = 0;
		for(int i=0; i<q.length; i++){
			sum += Math.exp(q[i] + logShift);
		}
		
		double logNorm = Math.log(sum) - logShift;
		for(int i=0; i<q.length; i++){
			q[i] -= logNorm;
		}
		return logNorm;
	}

	
	public static int[] copyArray(int[] wordCount) {
		int[] copy = new int[wordCount.length];
		for(int i=0; i<wordCount.length; i++){
			copy[i] = wordCount[i];
		}
		return copy;
	}
	
    public static long factorial( int n )
    {
        if( n <= 1 )     // base case
            return 1;
        else
            return n * factorial( n - 1 );
    }

	public static String readFileToString(File file) throws Exception{
		String content = "";
		BufferedReader in = new BufferedReader(new FileReader(file));

		while(true){
			String line = in.readLine();
			if(line == null) break;
			content += line;
		}
		
		in.close();
		return content;
	}

	public static List<Double> normalizeTopicDistribution(List<Double> weights)
	{
		List<Double> ret = new ArrayList<Double>();
		
		double sum = 0;
		for ( int i = 0 ; i < weights.size() ; i ++ )
			sum += weights.get(i).doubleValue();
		
		for ( int i = 0 ; i < weights.size() ; i ++ )
			ret.add( weights.get(i).doubleValue() / sum );
		
		return ret;
	}
	
	public static int[] createRandomSequence(int size, int seed, int iteration) {
		int [] ret = new int[size];
		
		for ( int i = 0 ; i < ret.length ; i ++ )
			ret[i] = i;
		
		Random rand = new Random(seed);
		for ( int i = 0 ; i < iteration ; i ++ )
		{
			int src = rand.nextInt(size);
			int tar = rand.nextInt(size);
			
			int temp = ret[src];
			ret[src] = ret[tar];
			ret[tar] = temp;
		}
		
		return ret;
	}
	
	public static Vector<String> makeVectorFromFile(String fileName) throws Exception{
		Vector<String> list = new Vector<String>();
		String line;
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));

		while((line = reader.readLine()) != null){
			list.add(line.toLowerCase());
		}
		
		reader.close();
		return list;
	}
	
	
	public static Vector<String> makeStemmedVectorFromFile(String fileName, boolean usingStemmer) throws Exception {
		Vector<String> list = new Vector<String>();
		String line;
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));

		while((line = reader.readLine()) != null){
			if(usingStemmer==true)list.add(stemmer.stemming(line.toLowerCase()));
			else list.add(line.toLowerCase());
		}
		
		reader.close();
		return list;
	}


	public static double arraySum(double[] m) {
		double sum =0;
		for(int i=0; i<m.length; i++){
			sum += m[i];
		}
		return sum;
	}

}
