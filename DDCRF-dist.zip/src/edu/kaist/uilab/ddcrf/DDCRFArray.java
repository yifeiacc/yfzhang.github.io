package edu.kaist.uilab.ddcrf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;

public class DDCRFArray {
	int array[];
	
	public DDCRFArray(int arraySize){
		array = new int[arraySize];
	}

	public void decrease(int wordNo) {
		array[wordNo] -= 1;
	}

	public void increase(int wordNo) {
		array[wordNo] += 1;		
	}

	public double get(int wi) {
		return array[wi];
	}

	public List<Entry<Integer,Integer>> getRankedList(){
		List<Entry<Integer,Integer>> rankedList = new ArrayList<Entry<Integer,Integer>>();
		for(int i=0; i<array.length ; i++){
			if(array[i] != 0){
				rankedList.add(new MyEntry(i, array[i]));
			}
		}
		
		Comparator<Entry<Integer,Integer>> c = new EntryComparator();
		Collections.sort(rankedList, c);
		return rankedList;
	}
}

class MyEntry implements Entry<Integer, Integer>{
	int key;
	int value;

	public MyEntry(int i, int j) {
		key = i;
		value = j;
	}

	@Override
	public Integer getKey() {
		return key;
	}

	@Override
	public Integer getValue() {
		return value;
	}

	@Override
	public Integer setValue(Integer value) {
		this.value = (Integer) value;
		return value;
	}

}